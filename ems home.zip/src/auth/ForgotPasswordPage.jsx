import React from "react";
import ForgotPasswordLayer from "../components/ForgotPasswordLayer";


const ForgotPasswordPage = () => {
  return (
    <>
      <ForgotPasswordLayer />

    </>
  );
};

export default ForgotPasswordPage;
