import React from "react";
import NewPasswordLayer from "../components/NewPasswordLayer";

const NewPassword = () => {
  return (
    <>

      {/* SignInLayer */}
      <NewPasswordLayer />

    </>
  );
};

export default NewPassword; 
