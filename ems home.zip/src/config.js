export const BASE_URL = 'https://crmsgateway.com/'
export const WS_URL = 'wss://crmsgateway.com/ws/'