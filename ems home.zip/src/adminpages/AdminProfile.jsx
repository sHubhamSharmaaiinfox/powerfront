import React from "react";
import AdminMasterLayer from "../masterLayout/AdminMasterLayer";
import AdminProfileLayer from "../components/AdminProfileLayer";


const AdminProfile = () => {
  return (
    <>
<AdminMasterLayer >

<AdminProfileLayer />       


</AdminMasterLayer>
    
    </>
  );
};

export default AdminProfile; 
