import React, { useEffect, useState } from 'react'



import AdminMasterLayer from '../masterLayout/AdminMasterLayer';
import FeedbackLayer from '../components/Feedbacklayer';



const Feedback = () => {


    return (


        <AdminMasterLayer>

        <FeedbackLayer />

        </AdminMasterLayer>
    );


}

export default Feedback