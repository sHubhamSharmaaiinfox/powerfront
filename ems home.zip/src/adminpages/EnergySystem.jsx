import React from "react";
import EnergyManagmentSyatem from "../components/EnergyManagmentSystem";
import AdminMasterLayer from "../masterLayout/AdminMasterLayer";
const EnergySystem = () => {
  return (
    <>
<AdminMasterLayer >
     
<EnergyManagmentSyatem/>

</AdminMasterLayer>
    
    </>
  );
};

export default EnergySystem; 
