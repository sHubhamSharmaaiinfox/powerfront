import React from 'react'
import PricingPlanMultipleColor from './child/PricingPlanMultipleColor'
import SimplePricingPlan from './child/SimplePricingPlan'

const PricingLayer = () => {
    return (
        <>

            <SimplePricingPlan />
        </>

    )
}

export default PricingLayer